package com.example.exoplayerdemo

import android.app.PictureInPictureParams
import android.content.SharedPreferences
import android.content.res.Configuration
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.exoplayerdemo.databinding.ActivityMainBinding
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.upstream.DefaultDataSource
import com.google.android.exoplayer2.util.MimeTypes

class MainActivity : AppCompatActivity() {

    var binding: ActivityMainBinding? = null
    var player: ExoPlayer? = null
    var currentDuration: Long? = 0
    var preferences: SharedPreferences? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        preferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        initializePlayer()
    }
    private fun initializePlayer(){
        currentDuration = preferences!!.getLong("Duration",0L)
        player = ExoPlayer.Builder(this@MainActivity).build()

        val mediaItem = MediaItem.Builder()
            .setUri("https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4")
            .setMimeType(MimeTypes.VIDEO_MP4)
            .build()

        val mediaSource = ProgressiveMediaSource.Factory(
            DefaultDataSource.Factory(this@MainActivity)
        ).createMediaSource(mediaItem)


        player?.apply {
            setMediaSource(mediaSource)
            playWhenReady = true
            seekTo(0, currentDuration!!)
            prepare()
        }.also {
            binding!!.playerView.player = it
        }
    }
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        var editor : SharedPreferences.Editor = preferences!!.edit()
        editor.putLong("Duration",player?.currentPosition!!)
        editor.apply()
        var params = PictureInPictureParams.Builder().build()
        enterPictureInPictureMode(params)
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if(isInPictureInPictureMode){
            Toast.makeText(this,"Entered Pip Mode", Toast.LENGTH_LONG).show()
        } else{
            Toast.makeText(this,"Escaped Pip Mode", Toast.LENGTH_LONG).show()
        }
    }
}